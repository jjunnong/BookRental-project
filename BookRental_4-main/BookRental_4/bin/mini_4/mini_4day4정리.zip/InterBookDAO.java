package mini_4;

import java.util.*;

public interface InterBookDAO {

	int bookregister(BookDTO bdto);//도서정보등록

	int unitbookRegister(BookDTO bdto);//개별도서등록

	boolean checkISBN(BookDTO bdto);//ISBN유무확인

	int setBookAgain(MemberDTO mdto); // 대여중에서 비치중으로 변경 하는 메소드

	List<BookDTO> selectAllBook(BookDTO bdto);//나의대여현황보기

	boolean checkBookId(BookDTO bdto); // 도서 id 조회
	
	int changeBookStatus(BookDTO bdto, MemberDTO mdto, Scanner sc); // 도서 상태 변경

	boolean isBookId(BookDTO bdto);// 도서 id 유무 확인


	

}
