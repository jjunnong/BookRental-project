package mini_4;

import java.sql.*;
import java.util.*;


import mini_4.singleton.dbconnection.ProjectDBConnection;

public class BookDAO implements InterBookDAO {

    // attribute, property, 속성
    Connection conn;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    PreparedStatement pstmt;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    ResultSet rs;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    
    // === 자원반납 메소드 === //
    public void close() {
       
       try {
          
          if(rs != null) rs.close();
          if(pstmt != null) pstmt.close();
          
       } catch (SQLException e) {
          e.printStackTrace();
       }
       
    }// end of private void close()------

    // 도서정보 등록하기
   	@Override
   	public int bookregister(BookDTO bdto) {
   		int result = 0;
   		
   		try {
   			conn = ProjectDBConnection.getConn();
   			
   			String sql = " insert into tbl_book(ISBN, bookCategory, bookName, bookAuthor, bookPbls, bookPblsDay, bookPrice) "
   					   + " values(?,?,?,?,?,?,?) ";
   			
   			pstmt = conn.prepareStatement(sql);
   			
   			pstmt.setString(1,bdto.getISBN());
   			pstmt.setString(2,bdto.getBookCategory());
   			pstmt.setString(3,bdto.getBookName());
   			pstmt.setString(4,bdto.getBookAuthor());
   			pstmt.setString(5,bdto.getBookPbls());
   			pstmt.setString(6,bdto.getBookPblsDay());
   			pstmt.setInt(7,bdto.getBookPrice());
   			
   			result = pstmt.executeUpdate();
   			//insert가 성공하면 result에는 1이 들어간다
   			
   			
   		} catch (SQLException e) {
   			e.printStackTrace();
   		}finally {
   			close();
   		}
		
		return result;
		// result는 1또는 0을 리턴할 것이다
	}// end of public int bookregister(BookDTO bdto)

	//개별도서등록
	@Override
	public int unitbookRegister(BookDTO bdto) {
		int result = 0;
		
		try {
			conn = ProjectDBConnection.getConn();
			
			String sql = " update tbl_book set bookID = ? "
					   + " where ISBN = ? ";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,bdto.getBookId());
			pstmt.setString(2,bdto.getISBN());
			
			result = pstmt.executeUpdate();
			//insert가 성공하면 result에는 1이 들어간다
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		
		return result;
	}//end of public int unitbookRegister(BookDTO bdto) 

	//ISBN유무확인
	@Override
	public boolean checkISBN(BookDTO bdto) {
		boolean result = false;
		
		try {
			conn = ProjectDBConnection.getConn();
			
			String sql = " select ISBN "
						+ " from tbl_book "
					    + " where ISBN = ? ";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,bdto.getISBN());
			
			rs = pstmt.executeQuery();
		
			if( rs.next())
				result = true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}		
		return result;
	}//end of public int checkISBN(BookDTO bdto)
	
	   // 대여중에서 비치중으로 변경 하는 메소드 <대여중(1)-> 비치중(0)으로 update>
		@Override
		public int setBookAgain(MemberDTO mdto) {
			int result = 0;
			
			try {
				conn = ProjectDBConnection.getConn();
				String sql = "update tbl_book set bookstatus = bookstatus -1\n"+
							 "where bookid = ?";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, mdto.getRentBook());
				
				result = pstmt.executeUpdate();
				
				if(result == 1) {
					conn.commit();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
			
			
			return result;
		}// end of public int setBookAgain(MemberDTO mdto)----------------

		//나의대여현황보기
		@Override
		public List<BookDTO> selectAllBook(BookDTO bdto) {
			
			List<BookDTO> bookList = new ArrayList<>();
			
			try {
			
			conn = ProjectDBConnection.getConn(); 
			String sql = " select ISBN, BookName, BookAuthor, BookPbls, BookRentMember, BookRentDay "
					+ " from tbl_book "
					+ " where BookRentMember = ? ";
			
			pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bdto.getBookRentMember());
      
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
            	BookDTO book = new BookDTO();
            	
            	book.setISBN(rs.getString(1));
            	book.setBookName(rs.getString(2));
            	book.setBookAuthor(rs.getString(3));
            	book.setBookPbls(rs.getString(4));
            	book.setBookRentMember(rs.getString(5));
            	book.setBookRentDay(rs.getString(6));
            	
            	bookList.add(book);
            }//end of while(rs.next())
            
		   } catch (SQLException e) {
	             e.printStackTrace();
	       } finally {
	            close();
	       }    
			return bookList;
		}//end of public List<BookDTO> selectAllBook(BookDTO bdto)

		// 도서 대여 상태 변경
		@Override
		public int changeBookStatus(BookDTO book) {

			int result =0;
			  
		       try {
		            conn = ProjectDBConnection.getConn(); // conn 은 수동commit 으로 되어져 있다.
		            
		            String sql = "update tbl_book set bookstatus = 1\n"+
		            		"where bookID = ? ";
		            
		            pstmt = conn.prepareStatement(sql);
		            
		            pstmt.setString(1, book.getBookId()); 
		            
		            result = pstmt.executeUpdate();
		            // update 가 성공되어지면 result 에는 1이 들어간다.
		      
		       } catch (SQLException e) {
		    	   e.printStackTrace();
		       }
		       finally {
		          close();
		       }
			
			return result;
		}//end of public int changeBookStatus(BookDTO book)
		
		// bookID 맞는 지 확인
		@Override
		public boolean checkBookId(BookDTO bdto) {
		
	 		boolean result=false;
	 		
	 		try {
	 			conn = ProjectDBConnection.getConn();
	 			
	 			String sql = " select bookid "
	 	                  + " from tbl_book "
	 	                   + " where bookid = ? ";
	 	         
	 	         pstmt = conn.prepareStatement(sql);
	 	         
	 	         pstmt.setString(1,bdto.getISBN());
	 	         
	 	         rs = pstmt.executeQuery();
	 	      
	 	         if( rs.next())
	 	            result = true;

	 			
	 		} catch (SQLException e) {
	 			e.printStackTrace();
	 		} finally {
	 			close();
	 		}		
	 		
	 		return result;
	 	}// end of public int checkBookId(BookDTO bdto)-----------------------

}
