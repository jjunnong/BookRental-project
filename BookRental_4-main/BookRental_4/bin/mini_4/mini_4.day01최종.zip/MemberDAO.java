package mini_4;

import java.sql.*;

public class MemberDAO implements InterMemberDAO {

    // attribute, property, 속성
    Connection conn;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    PreparedStatement pstmt;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    ResultSet rs;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    
    // === 자원반납 메소드 === //
    public void close() {
       
       try {
          
          if(rs != null) rs.close();
          if(pstmt != null) pstmt.close();
          
       } catch (SQLException e) {
          e.printStackTrace();
       }
       
    }// end of private void close()------
}
