package mini_4;

import java.util.Scanner;

public interface InterBookDAO {

	int bookregister(BookDTO bdto);
	

}
