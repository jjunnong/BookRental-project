package mini_4;


public interface InterMemberDAO {

}
