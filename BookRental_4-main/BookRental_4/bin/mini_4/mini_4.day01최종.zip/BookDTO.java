package mini_4;

public class BookDTO {


	   private String ISBN; //   국제표준도서번호(ISBN)  ex. 111-22-33333-44-5
	   private String bookId; // 도서 아이디
	   private String bookCategory; // 도서분류카테고리 
	   private String bookName; // 도서명
	   private String bookAuthor; // 작가명
	   private String bookPbls; // 출판사
	   private int bookPrice; // 책가격
	   private String bookstatus; // 책대여상태
	   private String bookRentDay; // 책 대여날짜
	   private String bookPblsDay; // 책 출판날짜
	   private String bookRentMember; // 책 대여해간 사람 
	   

	   public String getBookAuthor() {
		return bookAuthor;
		}
		public void setBookAuthor(String bookAuthor) {
			this.bookAuthor = bookAuthor;
		}
		public String getISBN() {
	      return ISBN;
	   }
	   public void setISBN(String iSBN) {
	      ISBN = iSBN;
	   }
	   public String getBookId() {
	      return bookId;
	   }
	   public void setBookId(String bookId) {
	      this.bookId = bookId;
	   }
	   public String getBookCategory() {
	      return bookCategory;
	   }
	   public void setBookCategory(String bookCategory) {
	      this.bookCategory = bookCategory;
	   }
	   public String getBookName() {
	      return bookName;
	   }
	   public void setBookName(String bookName) {
	      this.bookName = bookName;
	   }
	   public String getBookPbls() {
	      return bookPbls;
	   }
	   public void setBookPbls(String bookPbls) {
	      this.bookPbls = bookPbls;
	   }
	   public int getBookPrice() {
	      return bookPrice;
	   }
	   public void setBookPrice(int bookPrice) {
	      this.bookPrice = bookPrice;
	   }
	   public String getBookstatus() {
	      return bookstatus;
	   }
	   public void setBookstatus(String bookstatus) {
	      this.bookstatus = bookstatus;
	   }
	   public String getBookRentDay() {
	      return bookRentDay;
	   }
	   public void setBookRentDay(String bookRentDay) {
	      this.bookRentDay = bookRentDay;
	   }
	   public String getBookPblsDay() {
	      return bookPblsDay;
	   }
	   public void setBookPblsDay(String bookPblsDay) {
	      this.bookPblsDay = bookPblsDay;
	   }
	   public String getBookRentMember() {
	      return bookRentMember;
	   }
	   public void setBookRentMember(String bookRentMember) {
	      this.bookRentMember = bookRentMember;
	   }
}
