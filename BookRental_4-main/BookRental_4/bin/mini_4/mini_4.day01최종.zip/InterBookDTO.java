package mini_4;

public interface InterBookDTO {
	
}

