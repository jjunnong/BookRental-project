package mini_4;

import java.sql.*;
import java.util.Scanner;

import mini_4.singleton.dbconnection.ProjectDBConnection;

public class BookDAO implements InterBookDAO {

    // attribute, property, 속성
    Connection conn;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    PreparedStatement pstmt;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    ResultSet rs;// 초기 null값을 주지않아도 자동으로 null 값이 주어짐
    
    // === 자원반납 메소드 === //
    public void close() {
       
       try {
          
          if(rs != null) rs.close();
          if(pstmt != null) pstmt.close();
          
       } catch (SQLException e) {
          e.printStackTrace();
       }
       
    }// end of private void close()------

    // 도서정보 등록하기
	@Override
	public int bookregister(BookDTO bdto) {
		int result = 0;
		
		try {
			conn = ProjectDBConnection.getConn();
			
			String sql = " insert into tbl_book(ISBN, bookCategory, bookName, bookAuthor, bookPbls, bookPblsDay, bookPrice) "
					   + " values(?,?,?,?,?,?,?) ";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,bdto.getISBN());
			pstmt.setString(2,bdto.getBookCategory());
			pstmt.setString(3,bdto.getBookName());
			pstmt.setString(4,bdto.getBookAuthor());
			pstmt.setString(5,bdto.getBookPbls());
			pstmt.setString(6,bdto.getBookPblsDay());
			pstmt.setInt(7,bdto.getBookPrice());
			
			result = pstmt.executeUpdate();
			//insert가 성공하면 result에는 1이 들어간다
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close();
		}
		
		return result;
		// result는 1또는 0을 리턴할 것이다
	}
    
}
