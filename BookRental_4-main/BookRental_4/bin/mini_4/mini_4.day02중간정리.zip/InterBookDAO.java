package mini_4;

import java.util.List;
import java.util.Scanner;

public interface InterBookDAO {

	int bookregister(BookDTO bdto);//도서정보등록

	int unitbookRegister(BookDTO bdto);//개별도서등록

	int checkISBN(BookDTO bdto);//ISBN유무확인
	

}
