package mini_4;

import java.sql.*;
import java.util.*;


import mini_4.singleton.dbconnection.ProjectDBConnection;

public class TotalController {

	// attribute, property, 속성
	InterMemberDAO mdao = new MemberDAO();
	InterAdminDAO adao = new AdminDAO();
	InterBookDAO bdao = new BookDAO();
	
	
	// *** 시작메뉴 *** //
	public void menu_start(Scanner sc) {
				
		String s_Choice = "";		
		do {					
			System.out.println("\n ==== > 도서대여 프로그램 < ==== \n"
							 + "1.사서 전용메뉴	   2.일반회원 전용메뉴	   3.프로그램종료   ");
			System.out.print("▷ 메뉴번호 선택 : ");
			s_Choice = sc.nextLine();
			
			switch (s_Choice) {
	         case "1"://사서 전용메뉴
	            adminMenu(sc);
	            break;
	         case "2"://일반회원 전용메뉴
	            memberMenu(sc);
	            break;
	         case "3"://프로그램종료
	            //Connection 객체 자원 반납
	        	 ProjectDBConnection.closeConnection();
	            break;

	         default:
	            System.out.println("\n>>> 메뉴에 없는 번호입니다. 다시 선택하세요 <<<");
	            break;
	         }// end of switch (s_Choice)--------------------------------
			
		} while (!("3".equals(s_Choice)));
		
	}// end of public void menu_start(Scanner sc) ----------------
	
	// 사서 전용 메뉴
	private void adminMenu(Scanner sc) {
		  AdminDTO admin = null;
	      
	      String s_Choice = "";
	      
	      do {
	         String loginName = (admin != null)? "[" + admin.getAdminid()+ " 로그인중...]": "";
	         String login_logout = (admin==null)?"로그인":"로그아웃";
	               
	         System.out.println("\n >>> ----- 사서 전용 메뉴 "+loginName+" ----- <<< \n"
	                      + "1.사서가입    2."+login_logout+"  3.도서정보등록    4.개별도서등록\n"
	                      + "5.도서대여추가    6.대여중인도서조회    7.도서반납해주기    8.나가기");
	         System.out.print("▷메뉴번호 선택 : ");
	         s_Choice = sc.nextLine();
	         
	         switch (s_Choice) {
	         case "1": // 사서가입
	        	 adminResister(sc);
	            break;
	         case "2":            
	        	 if("로그인".equals(login_logout)) // 로그인시도하기
	                 admin = login(sc);
	               else {
	                  admin = null;// 로그아웃
	                   System.out.println("\n>> 로그아웃 되었습니다. <<");
	                }
	            break;
	         case "3":// 도서정보등록
	        	 if("로그아웃".equals(login_logout)) {//사서 로그인 상태인지 확인하기
	        		 int n = bookRegister(sc);
	        		
		        	if(n== 1) 
						System.out.println(">>> 도서정보등록 성공!! <<<\n");
					else
						System.out.println(">>> 도서정보등록 실패!! <<<\n");

	        	 }
	        	 else
	        		 System.out.println(">>> 먼저 로그인 해주세요 <<<");
	        	
	            break;
	            
	         case "4"://개별도서등록
	        	 if("로그아웃".equals(login_logout)) {//사서 로그인 상태인지 확인하기
	        		 int n = unitbookRegister(sc);
	        		
	        		 if(n== 1) 
	 					System.out.println(">>> 개별도서등록 성공!! <<<\n");
	 				 else
	 					System.out.println(">>> 개별도서등록 실패!! <<<\n");

	        	 }
	        	 else
	        		 System.out.println(">>> 먼저 로그인 해주세요 <<<");
	            break;
	            
	         case "5":
	            break;
	            
	         case "6"://대여중인도서조회
	        	 viewRentalBooks() ;
	            break;
	            
	         case "7":
	            break;
	            
	         case "8":
	            break;	           

	         default:
	            System.out.println("\n>>> 메뉴에 없는 번호입니다. 다시 선택하세요 <<<");
	            break;
	         }// end of switch (s_Choice)--------------------------------
	         
	      } while (!("8".equals(s_Choice)));
		
	}


	//사서 가입
	private void adminResister(Scanner sc) {
		 System.out.println("\n == 사서 가입 ==");
	      System.out.print("▶  사서ID : ");
	      String adminid = sc.nextLine();
	      
	      System.out.print("▶ 암호 : ");
	      String passwd = sc.nextLine();
	      
	      AdminDTO admin = new AdminDTO();
	      admin.setAdminid(adminid);
	      admin.setPasswd(passwd);
	      
	      int n = adao.adminResister(admin, sc);
	      
	         // 1값 리턴 => 정상적인 회원가입
	         // -1값 리턴 => 사용자 아이디에 중복이 발생한 것
	         // -2값 리턴 => 오류발생
	      switch (n) {
	      case 1:
	         System.out.println("\n >>> 사서등록 성공!! <<<");
	         break;
	      case 0:
	         System.out.println("\n >>> 사서등록을 취소하셨습니다. <<<");
	         break;
	      case -1:
	         System.out.println("\n >>> 아이디가 이미사용중이므로 다른 아이디를 입력하십시오. <<<");
	         break;
	      case -2:
	         System.out.println("\n >>> SQL구문에 오류가 발생하였습니다. <<<");
	         break;
	      }//end of switch()-----------------------
	   }//end of private void adminResister(Scanner sc)----

	//사서_로그인
	private AdminDTO login(Scanner sc) {
		 AdminDTO admin = null;
		    
		    System.out.println("\n >>> ---- 로그인 ---- <<<");
		    
		    System.out.print("▷ 사서아이디 : ");
		    String adminid = sc.nextLine();
		    System.out.print("▷ 암호 : ");
		    String passwd = sc.nextLine();
		    
		    Map<String, String> paraMap = new HashMap<String, String>();
		    paraMap.put("userid", adminid);
		    paraMap.put("passwd", passwd);
		    
		    admin = adao.login(paraMap);
		    
		    if(admin != null) {
		       System.out.println("\n >>> 로그인 성공!! <<< \n");
		    }
		    else {
		       System.out.println("\n >>> 로그인 실패!! <<< \n");
		    }
		    
		    return admin;
	}	

	//도서정보 등록하기
	private int bookRegister(Scanner sc) {
		int result = 0;
		String ISBN = null;
		
		System.out.println("== 도서정보 등록하기 ==");
		
		do {		
		System.out.print("▶ 국제표준도서번호(ISBN) : ");
		ISBN = sc.nextLine();
		
			if(ISBN.trim().isEmpty()) {
				//엔터 또는 공백일 경우
				System.out.println("~~~ 국제표준도서번호(ISBN)를 입력하세요 !! ~~~\n");
			}
		else
			break;
		}while (true);
			
		System.out.print("▶ 도서분류카테고리 : ");
		String bookCategory = sc.nextLine();
		System.out.print("▶ 도서명 : ");
		String bookName = sc.nextLine();
		System.out.print("▶ 작가명 : ");
		String bookAuthor = sc.nextLine();
		System.out.print("▶ 출판사 : ");
		String bookPbls = sc.nextLine();
		System.out.println("▶ 출판일자 : ");
		String bookPblsDay = sc.nextLine();
		
		int bookPrice = 0;
		do {
		try {
			System.out.print("▶ 가격 : ");
			bookPrice = Integer.parseInt(sc.nextLine());
		}catch(NumberFormatException e) {
			System.out.println("~~~ 오류 : 가격은 숫자로만 입력하세요!!! ~~~");
		}
		}while(bookPrice == 0);
		

		BookDTO bdto = new BookDTO();
		
		bdto.setISBN(ISBN);
		bdto.setBookCategory(bookCategory);
		bdto.setBookName(bookName);
		bdto.setBookAuthor(bookAuthor);
		bdto.setBookPbls(bookPbls);
		bdto.setBookPblsDay(bookPblsDay);
		bdto.setBookPrice(bookPrice);

		int n_insert = bdao.bookregister(bdto);
		
		Connection conn = ProjectDBConnection.getConn();
		
		try {
			if(n_insert == 1) {
				conn.commit();
				result = 1;
			}
			else {
				//SQL구문 장애가 발생한 경우
				conn.rollback();
				result = -1;
			}			
		}catch(SQLException e) {			
		}
		return result;
	}//end of private int bookRegister(Scanner sc)

	//개별도서등록
	private int unitbookRegister(Scanner sc) {
		
		int result = 0;

		System.out.println("== 개별도서 등록하기==");	
		String ISBN = null;
				
		System.out.print("▶ 국제표준도서번호(ISBN) : ");
		ISBN = sc.nextLine();	
		
		BookDTO bdto = new BookDTO();
		bdto.setISBN(ISBN);
		
		int check = bdao.checkISBN(bdto);
		if(check != 1) {
			System.out.println(">>> 등록된 ISBN이 아닙니다. 도서등록 실패!! <<<");
		}
		else {
			System.out.print("▶ 도서아이디 : ");
			String bookId = sc.nextLine();			
			bdto.setBookId(bookId);
			
			int n_insert = bdao.unitbookRegister(bdto);
			// n_insert는 성공시 1 실패시 0이들어온다
			
			Connection conn = ProjectDBConnection.getConn();
			
			try {
				if(n_insert == 1) {
					conn.commit();
					result = 1;
				}
				else {
					// SQL구문 장애가 발생한 경우
					conn.rollback();
					result = -1;
				}			
			}catch(SQLException e) {			
			}
		}
		return result;
	}// end of private int unitbookRegister(Scanner sc)
	
	//대여중인도서조회
	private void viewRentalBooks() {
		
		System.out.println("===============================================================================================");
		System.out.println(" 도서ID\t\t\tISBN\t\t\t도서명\t작가명\t출판사\t회원ID\t회원명\t연락처\t\t대여일자");
		System.out.println("===============================================================================================");
		
		List<Map<String, String>> mapList = adao.viewRentalBooks();
		
		if(mapList.size()>0) {
			StringBuilder sb = new StringBuilder();
			for(Map<String, String> map : mapList) {
				sb.append(map.get("bookid") + "\t\t\t"+ map.get("ISBN") +"\t\t\t"+ map.get("bookname") +"\t"+ map.get("bookauthor") +"\t"
						+ map.get("bookpbls") +"\t"+ map.get("userid") +"\t"+ map.get("mobile") +"\t"+ map.get("bookrentday") +"\n");

			}
			System.out.println(sb.toString());
		}
		else {
			System.out.println(">> 대여중인 도서가 없습니다 <<");
		}
		
	}//end of private void viewRentalBooks()
	
////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	// 회원 전용 메뉴 
	private void memberMenu(Scanner sc) {
		MemberDTO member = null;
		String s_Choice = "";
		
		do {
			String login_logout = (member==null)?"로그인":"로그아웃";
			String loginName = (member != null)? "[" + member.getName()+ " 로그인중...]": "";
			
			System.out.println("\n >>> ----- 일반회원 전용 메뉴"+loginName+" ----- <<<\n"
					+ " 1. 일반회원가입   2."+login_logout+"  3.도서검색하기   4.나의대여현황보기   5.나가기\n");
			System.out.print("▷ 메뉴번호 선택 : ");
			s_Choice = sc.nextLine();
			
			switch (s_Choice) {
			case "1"://일반회원가입			
				break;
			case "2"://로그인, 로그아웃			
				break;
			case "3"://도서검색하기			
				break;
			case "4"://나의대여현황보기			
				break;	
			default:
				System.out.println("\n>>> 메뉴에 없는 번호입니다. 다시 선택하세요 <<<");
				break;
		}//end of switch (s_Choice)
		}while(!("5".equals(s_Choice)));
		
		
	}//end of private void memberMenu(Scanner sc)




}
